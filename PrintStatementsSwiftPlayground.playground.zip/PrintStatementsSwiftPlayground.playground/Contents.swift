import UIKit

var greeting = "Hello, playground"
print(greeting)

print("Hi", 10, 10.23)

//var i = 10
//print("This is ten"+i)
//+ cannot be used for concatinating same data types.

var name1 = "Anjali"
print("Hello, \(name1)!")
print("Hello, "+name1+"!")

print("""
Hello, World!
From Maryville,
Mo.
😁
Alright!
""")

var age = 23
print("You are \(age) years old  and in another \(age) years, you will be \(age * 2)")

print(age-10)
age = age+10
print(age)
print(33*2)

print("Hello All,\rWelcome to swift Programming")

var name2  = "Bhogireddy"
var name3 = "Northwest Missouri State University"
print("\(name1) \(name2) is a student of \(name3)")

var i1 = 2023
var i3 = 2022
print("I have started my Masters in \(i3) and i will be completing it on \(i3)")

let PI = 3.14
print(PI-2)
//PI = PI - 2; Constant values can be manipulated but could not be changed.
print(PI)

//Explicit declaration of datatypes
//var p = 99.9
var p:Double = 99.9
//var k = -28
var k:Int = -28

//var welcomeMessage = "Hello!"
let welcomeMessage : String = "Hello!"
print(welcomeMessage , "All")


print("Welcome to Swift Programming")
print("Fall 2021")
print("*************")
print("Welcome to Swift Programming" , terminator : "-" )
print("Fall 2021")
//terminator works for next line

print("The list of numbers are ")
print(1,2,3,4,5,6)
print("The new pattern is")
print(1,2,3,4,5,6, separator: "-")
//seperator works as space
