//
//  ViewController.swift
//  ProductApp
//
//  Created by Bhogireddy,Anjali on 4/18/23.
//

import UIKit

class Product{
    var productName: String?
    var productCategory: String?
    
    init(productName: String, productCategory: String) {
        self.productName = productName
        self.productCategory = productCategory
    }
}



class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //create a cell
        var cell = tableViewOutlet.dequeueReusableCell(withIdentifier:  "reusableCell", for: indexPath)
                
        //populate a cell
        cell.textLabel?.text = productArray[indexPath.row].productName
                
        //return a cell
        return cell
    }
    
    
    
    @IBOutlet weak var tableViewOutlet: UITableView!
    
    var productArray = [Product]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        tableViewOutlet.delegate = self
        tableViewOutlet.dataSource = self
        let p1 = Product(productName: "MacBookAir", productCategory: "Laptop")
        productArray.append(p1)
                
        let p2 = Product(productName: "iPhone", productCategory: "cellPhone")
        productArray    .append(p2)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
                if transition == "AppleProductDetails"{
                    let destination = segue.destination as! ResultViewController
                    
                    destination.product = productArray[(tableViewOutlet.indexPathForSelectedRow?.row)!]
                }
    }


}

