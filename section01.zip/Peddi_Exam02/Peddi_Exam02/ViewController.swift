//
//  ViewController.swift
//  Peddi_Exam02
//
//  Created by Peddi,Venkataramana on 4/11/23.
//

import UIKit

class ViewController: UIViewController {

   
    
    @IBOutlet weak var courseid: UITextField!
    
    @IBOutlet weak var studentid: UITextField!
    
    @IBOutlet weak var displaylabel: UILabel!
    
    @IBOutlet weak var crsbtn: UIButton!
    
    @IBOutlet weak var enbtn: UIButton!
    
    @IBOutlet weak var image: UIImageView!
    
    var courses  = CoursesArray
    
    var o = CourseDetails()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        crsbtn.isEnabled = false
        enbtn.isHidden = true
        o = CourseDetails()
    }
     
    @IBAction func curse(_ sender: Any) {
        crsbtn.isEnabled = true
    }
    
    @IBAction func coursecheck(_ sender: Any) {
        
        var enter = courseid.text!
        
     
        for c in CoursesArray {
                   if enter == c.courseID{
                       
                       displaylabel.text = enter+" is open for registration"
                       image.image = UIImage(named: c.courseImage)
                       enbtn.isHidden = false
                       o = c
                       break
                   }
            else if enter != c.courseID{
                displaylabel.text = "Course Id not found"
                image.image = UIImage(named: "default")
                enbtn.isHidden = true
            }
               }
        
        
        
        
    }
    
    @IBAction func enrlcheck(_ sender: Any) {
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            let transition = segue.identifier
            if transition == "result"{
                //Create a destination of type studentInfoViewController
                let destination = segue.destination as! resultViewController
                destination.id = studentid.text!
                destination.ob = o
                
    
    
            }}

}
