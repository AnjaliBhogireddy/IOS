//
//  ImageViewController.swift
//  SAMPLEAPP
//
//  Created by Bhogireddy,Anjali on 4/10/23.
//

import UIKit

class ImageViewController: UIViewController {
    
    @IBOutlet weak var ImageOL: UIImageView!
    
    var image : Double = 0.0
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        if(image<18.5){
            //making the current image opaque.
            UIView.animate(withDuration: 1, animations: {
                self.ImageOL.alpha = 0
            })
            
            
            UIView.animate(withDuration: 1, delay:0.5, animations: {
                self.ImageOL.alpha = 1
                self.ImageOL.image = UIImage(named: "Underweight")
            })
            //ImageOL.image = UIImage(named: "Underweight")
        }
        else if(image > 24.9){
            UIView.animate(withDuration: 1, animations: {
                self.ImageOL.alpha = 0
            })
            UIView.animate(withDuration: 1, delay:0.5, animations: {
                self.ImageOL.alpha = 1
                self.ImageOL.image = UIImage(named: "Overweight")
                
            })
            //ImageOL.image = UIImage(named: "Overweight")
        }else{
            UIView.animate(withDuration: 1, animations: {
                self.ImageOL.alpha = 0
            })
            
            UIView.animate(withDuration: 1, delay:0.5, animations: {
                self.ImageOL.alpha = 1
                self.ImageOL.image = UIImage(named: "IdealWeight")
            })
            //ImageOL.image = UIImage(named: "IdealWeight")
        }
        
        
        /*
         // MARK: - Navigation
         
         // In a storyboard-based application, you will often want to do a little preparation before navigation
         override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
         // Get the new view controller using segue.destination.
         // Pass the selected object to the new view controller.
         }
         */
        
    }
}
