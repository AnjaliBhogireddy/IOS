import UIKit

var greeting = "Hello, playground"
print(greeting)
var grade = 90
print(grade)
